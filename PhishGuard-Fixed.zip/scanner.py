
import re, os, base64, requests, psycopg2
from dotenv import load_dotenv
load_dotenv()
VT_API_KEY = os.getenv("VT_API_KEY", "").strip()
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
VT_BASE = "https://www.virustotal.com/api/v3"

def detect_input_type(value: str) -> str:
    value = value.strip()
    if re.fullmatch(r"[a-fA-F0-9]{64}", value): return "hash_sha256"
    if re.fullmatch(r"[a-fA-F0-9]{40}", value): return "hash_sha1"
    if re.fullmatch(r"[a-fA-F0-9]{32}", value): return "hash_md5"
    if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value): return "email"
    if re.match(r"^(https?://|hxxp://|www\.)", value, re.I) or re.match(r"^[a-z0-9.-]+\.[a-z]{2,}(/.*)?$", value, re.I):
        return "url"
    return "unknown"

def extract_domain_from_email(email: str) -> str:
    return email.split("@")[-1].lower().strip()

def _headers(): return {"x-apikey": VT_API_KEY}

def scan_url(url: str):
    if not VT_API_KEY: return {"error": "VT_API_KEY not set"}
    url = re.sub(r"^hxxp", "http", url, flags=re.I)
    url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    r = requests.get(f"{VT_BASE}/urls/{url_id}", headers=_headers(), timeout=15)
    if r.status_code == 200:
        stats = r.json()["data"]["attributes"]["last_analysis_stats"]
        return {"malicious": stats["malicious"], "suspicious": stats["suspicious"], "harmless": stats["harmless"], "undetected": stats["undetected"], "total": sum(stats.values()), "stats": stats}
    r = requests.post(f"{VT_BASE}/urls", headers=_headers(), data={"url": url}, timeout=15)
    if r.status_code in [200,201]: return {"malicious": 0, "suspicious": 0, "total": 0, "msg": "URL submitted, scan pending. Try again in 30s."}
    return {"error": f"VT Error {r.status_code}"}

def scan_hash(hash_val: str):
    if not VT_API_KEY: return {"error": "VT_API_KEY not set"}
    r = requests.get(f"{VT_BASE}/files/{hash_val}", headers=_headers(), timeout=15)
    if r.status_code == 200:
        stats = r.json()["data"]["attributes"]["last_analysis_stats"]
        return {"malicious": stats["malicious"], "suspicious": stats["suspicious"], "harmless": stats["harmless"], "undetected": stats["undetected"], "total": sum(stats.values()), "stats": stats}
    return {"malicious": 0, "total": 0, "msg": "No report found for this hash"}

def scan_domain(domain: str):
    if not VT_API_KEY: return {"error": "VT_API_KEY not set"}
    r = requests.get(f"{VT_BASE}/domains/{domain}", headers=_headers(), timeout=15)
    if r.status_code == 200:
        stats = r.json()["data"]["attributes"]["last_analysis_stats"]
        return {"malicious": stats["malicious"], "suspicious": stats["suspicious"], "harmless": stats["harmless"], "undetected": stats["undetected"], "total": sum(stats.values()), "stats": stats}
    return {"error": "Domain not found on VT"}

def init_db():
    if not DATABASE_URL: return
    try:
        con = psycopg2.connect(DATABASE_URL)
        with con, con.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS scans (
                    id SERIAL PRIMARY KEY,
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    input_value TEXT NOT NULL,
                    input_type TEXT NOT NULL,
                    malicious INT NOT NULL,
                    total INT NOT NULL,
                    status TEXT NOT NULL
                );
            """)
        con.close()
    except Exception as e: print("Neon Init Error:", e)

def log_to_neon(input_value, input_type, malicious, total, status):
    if not DATABASE_URL: return
    try:
        con = psycopg2.connect(DATABASE_URL)
        with con, con.cursor() as cur:
            cur.execute("INSERT INTO scans (input_value, input_type, malicious, total, status) VALUES (%s,%s,%s,%s,%s)", (input_value[:500], input_type, malicious, total, status))
        con.close()
    except Exception as e: print("Neon Log Error:", e)

def auto_scan(user_input: str):
    input_type = detect_input_type(user_input)
    if input_type.startswith("hash"): vt = scan_hash(user_input)
    elif input_type == "email": vt = scan_domain(extract_domain_from_email(user_input))
    elif input_type == "url":
        if not user_input.startswith("http"): user_input = "https://" + user_input
        vt = scan_url(user_input)
    else: return {"input": user_input, "type": "unknown", "error": "Invalid input. Enter a valid URL, Email or Hash."}
    malicious = vt.get("malicious", 0)
    total = vt.get("total", 0)
    if vt.get("error"): status = "error"
    elif malicious >= 3: status = "malicious"
    elif malicious > 0: status = "suspicious"
    else: status = "clean"
    log_to_neon(user_input, input_type, malicious, total, status)
    return {"input": user_input, "type": input_type, "malicious": malicious, "total": total, "status": status, "vt_raw": vt}
init_db()
